﻿(function() {
    angular.module('app', ['ngRoute', 'ngMaterial', 'ngMessages']);
})();